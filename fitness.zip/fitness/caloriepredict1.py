import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split  #spliting of data set
from xgboost import XGBRegressor  
from sklearn import metrics    # evaluate our model
import joblib
#data collection


cal_data = pd.read_csv('calories.csv')
# print(cal.head())  
#     User_ID  Gender  Age  Height  Weight  Duration  Heart_Rate  Body_Temp  Calories
# 0  14733363    male   68   190.0    94.0      29.0       105.0       40.8     231.0
# 1  14861698  female   20   166.0    60.0      14.0        94.0       40.3      66.0
# 2  11179863    male   69   179.0    79.0       5.0        88.0       38.7      26.0
# 3  16180408  female   34   179.0    71.0      13.0       100.0       40.5      71.0
# 4  17771927  female   27   154.0    58.0      10.0        81.0       39.8      35.0
exercise_data = pd.read_csv('exercise.csv')

# print(exercise_data.head())


#classify the one one with higher heart rate is performing more excercise 
# and hence has higher calorie burn so combining the 2 above data set will give the 
# idea of mapping bw heart rfate , body temp and calories burned

caloriesCombined = pd.concat([exercise_data,cal_data['Calories']],axis=1)  #adding calories column col-wise
# print(caloriesCombined.head())

# print(caloriesCombined.shape)  ---->   (15000, 9)



# print(caloriesCombined.info())     there are no null value 
# missing values:
# print(caloriesCombined.isnull().sum())  show the count of missing values in each column

# data analysis

# print(caloriesCombined.describe())

#data visualisation

sns.set()

# sns.countplot(x='Gender', data=caloriesCombined)    set of male and female are equally same
# sns.distplot(caloriesCombined['Age'])   age of 20 has max density

# sns.distplot(caloriesCombined['Height'])  normal distribution with max heights from 160 to 180
# sns.distplot(caloriesCombined['Weight'])   weight has maxium density from 60-70 1and 80-100
# sns.distplot(caloriesCombined['Heart_Rate'])
# plt.show()

numeric_data = caloriesCombined.select_dtypes(include=['float64', 'int64'])

# Calculate the correlation matrix
# correl = numeric_data.corr()

# plt.figure(figsize=(10, 10))
# sns.heatmap(correl, cbar=True, square=True, fmt='.1f', annot=True, annot_kws={'size': 8}, cmap='Blues')
# plt.show()

# male=0,female=1
caloriesCombined.replace({"Gender":{'male':0,'female':1}},inplace=True)
# print(caloriesCombined.head())

x=caloriesCombined.drop(columns=['User_ID','Calories'],axis=1)
y=caloriesCombined['Calories']
# print(x)
# print(y)

x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,random_state=2)
# print("done")
# print(x.shape, x_train.shape,x_test.shape)    (15000, 7) (12000, 7) (3000, 7)


# model train

model = XGBRegressor()

model.fit(x_train,y_train)
# prediction
pred = model.predict(x_test)
# print(pred)

meanAbsError = metrics.mean_absolute_error(y_test,pred)
# print(meanAbsError)  ---->  1.4833678883314132

# Save the model
joblib.dump(model, 'calorie_predictor_model.pkl')

# Load the model
loaded_model = joblib.load('calorie_predictor_model.pkl')

# Predict function
def predict_calories(gender, age, height, weight, duration, heart_rate, body_temp):
    # Prepare the input data
    input_data = pd.DataFrame([[gender, age, height, weight, duration, heart_rate, body_temp]],
                              columns=['Gender', 'Age', 'Height', 'Weight', 'Duration', 'Heart_Rate', 'Body_Temp'])
    
    # Predict using the model
    prediction = loaded_model.predict(input_data)
    return prediction[0]

# Example usage

calories_burned = predict_calories(1, 43, 175, 72, 23, 100, 40.7)
print("Predicted Calories Burned:", calories_burned)
