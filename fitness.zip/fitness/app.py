from flask import Flask, request, render_template
import pandas as pd
import joblib
import caloriepredict1

app = Flask(__name__)

# Load the model
model = joblib.load('calorie_predictor_model.pkl')

def predict_calories(gender, age, height, weight, duration, heart_rate, body_temp):
    # Prepare the input data
    input_data = pd.DataFrame([[gender, age, height, weight, duration, heart_rate, body_temp]],
                              columns=['Gender', 'Age', 'Height', 'Weight', 'Duration', 'Heart_Rate', 'Body_Temp'])
    
    # Predict using the model
    prediction = model.predict(input_data)
    return prediction[0]

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        gender = int(request.form['Gender'])
        age = float(request.form['Age'])
        height = float(request.form['Height'])
        weight = float(request.form['Weight'])
        duration = float(request.form['Duration'])
        heart_rate = float(request.form['Heart_Rate'])
        body_temp = float(request.form['Body_Temp'])

        # Get the prediction
        calories_burned = predict_calories(gender, age, height, weight, duration, heart_rate, body_temp)
        
        return render_template('index.html', calories_burned=calories_burned)
    
    return render_template('index.html', calories_burned=None)

if __name__ == '__main__':
    app.run(debug=True)
