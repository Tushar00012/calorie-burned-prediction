import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn import metrics
import joblib

# Data collection
cal_data = pd.read_csv('calories.csv')
exercise_data = pd.read_csv('exercise.csv')

# Combine datasets
caloriesCombined = pd.concat([exercise_data, cal_data['Calories']], axis=1)

# Data preprocessing
caloriesCombined.replace({"Gender": {'male': 0, 'female': 1}}, inplace=True)
x = caloriesCombined.drop(columns=['User_ID', 'Calories'], axis=1, errors='ignore')
y = caloriesCombined['Calories']

# Split the data
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=2)

# Model training
model = DecisionTreeRegressor(random_state=2)
model.fit(x_train, y_train)

# Predictions
pred = model.predict(x_test)

# Model evaluation
meanAbsError = metrics.mean_absolute_error(y_test, pred)
print("Mean Absolute Error:", meanAbsError)

# Save the model
joblib.dump(model, 'calorie_predictor_model_dt.pkl')

# Load the model
loaded_model = joblib.load('calorie_predictor_model_dt.pkl')

# Predict function
def predict_calories(gender, age, height, weight, duration, heart_rate, body_temp):
    # Prepare the input data
    input_data = pd.DataFrame([[gender, age, height, weight, duration, heart_rate, body_temp]],
                              columns=['Gender', 'Age', 'Height', 'Weight', 'Duration', 'Heart_Rate', 'Body_Temp'])
    
    # Predict using the model
    prediction = loaded_model.predict(input_data)
    return prediction[0]

# Example usage with new input values
calories_burned = predict_calories(1, 43, 175, 72, 23, 100, 40.7)
print("Predicted Calories Burned:", calories_burned)
